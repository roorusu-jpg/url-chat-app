const startView = document.getElementById("startView");
const chatView = document.getElementById("chatView");
const nameInput = document.getElementById("name");
const createBtn = document.getElementById("createBtn");
const roomUrl = document.getElementById("roomUrl");
const copyBtn = document.getElementById("copyBtn");
const statusEl = document.getElementById("status");
const messagesEl = document.getElementById("messages");
const sendForm = document.getElementById("sendForm");
const textInput = document.getElementById("text");

let ws;
let currentName = localStorage.getItem("chatName") || "";

nameInput.value = currentName;

function addMessage(message) {
  const wrap = document.createElement("div");
  wrap.className = "message";

  const meta = document.createElement("div");
  meta.className = "meta";
  const time = new Date(message.time);
  meta.textContent = `${message.name} · ${time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;

  const body = document.createElement("div");
  body.className = "body";
  body.textContent = message.text;

  wrap.append(meta, body);
  messagesEl.appendChild(wrap);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function addSystem(text) {
  const el = document.createElement("div");
  el.className = "system";
  el.textContent = text;
  messagesEl.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function createRoom() {
  currentName = nameInput.value.trim() || "匿名";
  localStorage.setItem("chatName", currentName);

  const res = await fetch("/api/room");
  const data = await res.json();
  location.href = `/room/${data.id}`;
}

createBtn.addEventListener("click", createRoom);

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(roomUrl.value);
    copyBtn.textContent = "コピーしました";
    setTimeout(() => copyBtn.textContent = "URLをコピー", 1200);
  } catch {
    roomUrl.select();
    document.execCommand("copy");
  }
});

sendForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const text = textInput.value.trim();
  if (!text || !ws || ws.readyState !== WebSocket.OPEN) return;

  ws.send(JSON.stringify({
    name: currentName || "匿名",
    text
  }));

  textInput.value = "";
  textInput.focus();
});

const match = location.pathname.match(/^\/room\/([^/]+)$/);

if (match) {
  const roomId = decodeURIComponent(match[1]);
  currentName = localStorage.getItem("chatName") || "匿名";

  startView.hidden = true;
  chatView.hidden = false;
  roomUrl.value = location.href;

  const protocol = location.protocol === "https:" ? "wss:" : "ws:";
  ws = new WebSocket(`${protocol}//${location.host}?room=${encodeURIComponent(roomId)}`);

  ws.addEventListener("open", () => {
    statusEl.textContent = "接続しました";
  });

  ws.addEventListener("close", () => {
    statusEl.textContent = "接続が切れました";
  });

  ws.addEventListener("error", () => {
    statusEl.textContent = "接続エラー";
  });

  ws.addEventListener("message", (event) => {
    const data = JSON.parse(event.data);

    if (data.type === "history") {
      messagesEl.innerHTML = "";
      data.messages.forEach(addMessage);
    } else if (data.type === "message") {
      addMessage(data.message);
    } else if (data.type === "system") {
      addSystem(data.text);
    }
  });
}

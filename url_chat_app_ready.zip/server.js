const express = require("express");
const http = require("http");
const path = require("path");
const { WebSocketServer } = require("ws");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const PORT = process.env.PORT || 3000;
const rooms = new Map();

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/room", (req, res) => {
  const id = crypto.randomBytes(4).toString("hex");
  rooms.set(id, { clients: new Set(), messages: [] });
  res.json({ id });
});

app.get("/room/:id", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

function getRoom(id) {
  if (!rooms.has(id)) {
    rooms.set(id, { clients: new Set(), messages: [] });
  }
  return rooms.get(id);
}

function broadcast(room, data) {
  const message = JSON.stringify(data);
  for (const client of room.clients) {
    if (client.readyState === 1) client.send(message);
  }
}

wss.on("connection", (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const roomId = url.searchParams.get("room");

  if (!roomId) {
    ws.close(1008, "Room is required");
    return;
  }

  const room = getRoom(roomId);
  room.clients.add(ws);

  ws.send(JSON.stringify({
    type: "history",
    messages: room.messages
  }));

  broadcast(room, {
    type: "system",
    text: "誰かが参加しました"
  });

  ws.on("message", (raw) => {
    try {
      const data = JSON.parse(raw.toString());
      const text = String(data.text || "").trim();
      const name = String(data.name || "匿名").trim().slice(0, 30);

      if (!text) return;

      const message = {
        id: crypto.randomUUID(),
        name: name || "匿名",
        text: text.slice(0, 1000),
        time: new Date().toISOString()
      };

      room.messages.push(message);
      if (room.messages.length > 100) room.messages.shift();

      broadcast(room, {
        type: "message",
        message
      });
    } catch {
      // Ignore malformed messages.
    }
  });

  ws.on("close", () => {
    room.clients.delete(ws);
    broadcast(room, {
      type: "system",
      text: "誰かが退出しました"
    });
  });
});

setInterval(() => {
  for (const [id, room] of rooms) {
    if (room.clients.size === 0 && room.messages.length === 0) {
      rooms.delete(id);
    }
  }
}, 60_000);

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Chat app listening on port ${PORT}`);
});
